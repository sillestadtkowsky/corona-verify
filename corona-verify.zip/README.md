# corona-verify
App zeigt den Status eines durchgeführten Tests an
